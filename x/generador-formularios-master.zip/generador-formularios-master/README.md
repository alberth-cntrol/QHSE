# Sistema Generador de Formularios en PHP y MySQL
<img src=Sistema%20Generador%20de%20Formularios%20en%20PHP%20y%20MySQL.png>
Este sistema tiene las opciones de crear, editar, eliminar y ver formularios así como las respuestas de los usuarios. Se comparte el código totalmente gratis.

# Base de datos Sistema Generador de Formularios en PHP y MySQL
Este sistema para su funcionamiento requiere de la base de datos que se encuentra en el siguiente enlace donde está el post relacionado con la aplicación:
https://www.configuroweb.com/46-aplicaciones-gratuitas-en-php-python-y-javascript/#Sistema-Generador-de-Formularios-en-PHP-y-MySQL

