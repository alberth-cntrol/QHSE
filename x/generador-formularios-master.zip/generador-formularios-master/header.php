
<link rel="stylesheet" href="./fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="./css/bootstrap.min.css">
<link rel="stylesheet" href="./DataTables/datatables.min.css">
<link rel="stylesheet" href="./css/custom.css">
<script src="./js/jquery-3.6.0.min.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/jquery-ui.js"></script>
<script src="./js/bootstrap.min.js"></script>
<script src="./DataTables/datatables.min.js"></script>
<script src="./js/script.js"></script>
